package dx.queen.truecontactmanager.view

import android.support.v4.app.Fragment

class ContactsFragment : Fragment(){

}