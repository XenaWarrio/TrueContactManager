package dx.queen.truecontactmanager.viewModel

class ContactsViewModel {
}